# ============================================================
# MazgirtAI - Anonymous AI Assistant (Yerel Masaüstü Versiyonu)
# Bu dosya: Phi-3-mini modelini yerelde 4-bit modda çalıştırır.
# Sohbet geçmişi TUTMAZ → tamamen anonim.
# Arayüz: Tkinter (yerel pencere, Windows/Linux/Android uyumlu)
# ============================================================

import tkinter as tk
from tkinter import scrolledtext
import threading

# ------------------------------------------------------------
# AŞAMA 1: Phi-3-mini modelini 4-bit quantization ile yükle
# Bu, 4 GB RAM bile olsa çalışmasını sağlar.
# İlk çalıştırmada ~2.3 GB model indirilir.
# ------------------------------------------------------------
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
    import torch

    print("[+] Phi-3-mini modeli yükleniyor...")

    model_id = "microsoft/Phi-3-mini-4k-instruct"
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        device_map="auto",
        torch_dtype=torch.float16,
        load_in_4bit=True,        # RAM tasarrufu için kritik!
        trust_remote_code=True
    )
    ai_pipeline = pipeline("text-generation", model=model, tokenizer=tokenizer, max_new_tokens=256)
    MODEL_READY = True
except Exception as e:
    MODEL_READY = False
    MODEL_ERROR = str(e)

# ------------------------------------------------------------
# AŞAMA 2: Çokdilli kimlik ve davranış kuralları
# Hem Türkçe hem İngilizce soruları tanır.
# "Phi-3-mini tabanlıyım" sadece açıkça sorulursa söylenir.
# ------------------------------------------------------------
def get_identity_response(user_input: str) -> str or None:
    lower = user_input.lower().strip()
    
    # Kimlik soruları (Türkçe + İngilizce)
    identity_keywords = [
        # Türkçe
        "kim", "geliştirdi", "yaptı", "adın", "ismin", "kimsin",
        # İngilizce
        "who", "made you", "created you", "your name", "are you", "developer"
    ]
    
    # Taban model soruları (Türkçe + İngilizce)
    base_keywords = [
        # Türkçe
        "taban", "model", "temel", "neyle", "ne üzerine",
        # İngilizce
        "base", "based on", "foundation", "underlying", "what model", "architecture"
    ]

    # Kimlik sorusu mu?
    is_identity = any(word in lower for word in identity_keywords)
    if not is_identity:
        return None

    # Cevap oluştur
    response = "Ben MazgirtAI. Beni Serçiyan Deniz MAK geliştirdi."
    
    # Taban model soruldu mu?
    is_base = any(word in lower for word in base_keywords)
    if is_base:
        response += " Phi-3-mini tabanlıyım."
    
    return response

# ------------------------------------------------------------
# AŞAMA 3: Ana GUI (Tkinter)
# Dark purple tema, başlık, giriş kutusu, anonim çalışma.
# ------------------------------------------------------------
class MazgirtAIGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("MazgirtAI - Anonymous AI Assistant")
        self.root.geometry("700x500")
        self.root.configure(bg="#1a0a1f")  # Dark purple arka plan

        # Başlık etiketi
        title = tk.Label(
            root,
            text="MazgirtAI - Anonymous AI Assistant",
            bg="#1a0a1f",
            fg="#d8b4fe",
            font=("Arial", 14, "bold")
        )
        title.pack(pady=10)

        # Yanıt alanı (kaydırılabilir, salt okunur)
        self.output = scrolledtext.ScrolledText(
            root,
            wrap=tk.WORD,
            bg="#2a1a2f",
            fg="#f0e6ff",
            insertbackground="#d8b4fe",
            font=("Consolas", 10),
            state=tk.DISABLED,
            relief=tk.FLAT
        )
        self.output.pack(padx=20, pady=10, fill=tk.BOTH, expand=True)

        # Giriş alanı ve buton
        input_frame = tk.Frame(root, bg="#1a0a1f")
        input_frame.pack(padx=20, pady=(0, 10), fill=tk.X)

        self.entry = tk.Entry(
            input_frame,
            bg="#3a2a3f",
            fg="white",
            insertbackground="#d8b4fe",
            font=("Arial", 11),
            relief=tk.FLAT
        )
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=5)
        self.entry.bind("<Return>", self.send_message)

        send_btn = tk.Button(
            input_frame,
            text="Gönder",
            bg="#6a3a8f",
            fg="white",
            relief=tk.FLAT,
            command=self.send_message
        )
        send_btn.pack(side=tk.RIGHT, padx=(10, 0))

        # Başlangıç mesajı
        self.append_output("MazgirtAI başlatılıyor...\n")
        if not MODEL_READY:
            self.append_output(f"[HATA] Model yüklenemedi: {MODEL_ERROR}\n")
        else:
            self.append_output("✅ Hazır! Sorularınızı yazabilirsiniz.\n")

    def append_output(self, text):
        self.output.config(state=tk.NORMAL)
        self.output.insert(tk.END, text + "\n")
        self.output.config(state=tk.DISABLED)
        self.output.see(tk.END)

    def send_message(self, event=None):
        user_text = self.entry.get().strip()
        if not user_text:
            return
        self.append_output(f"Sen: {user_text}")
        self.entry.delete(0, tk.END)

        # Kimlik sorusuysa hemen cevapla (çokdilli)
        identity_resp = get_identity_response(user_text)
        if identity_resp:
            self.append_output(f"MazgirtAI: {identity_resp}")
            return

        # Normal soru → model
        if not MODEL_READY:
            self.append_output("[HATA] Model çalışmıyor.")
            return

        def run_ai():
            try:
                messages = [{"role": "user", "content": user_text}]
                result = ai_pipeline(messages)
                generated = result[0]['generated_text']
                if isinstance(generated, list):
                    response = generated[-1]['content']
                else:
                    response = generated.replace(user_text, "").strip()
                self.append_output(f"MazgirtAI: {response}")
            except Exception as e:
                self.append_output(f"[HATA] {str(e)}")

        threading.Thread(target=run_ai, daemon=True).start()

# ------------------------------------------------------------
# AŞAMA 4: Uygulamayı başlat
# ------------------------------------------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = MazgirtAIGUI(root)
    root.mainloop()